function toggleLogout() {
    var logoutContainer = document.getElementById("logoutContainer");
    logoutContainer.style.display = (logoutContainer.style.display === "block") ? "none" : "block";
}
